
#ifndef BSP_CFG_LPITCOM1_H_
#define BSP_CFG_LPITCOM1_H_

#include "clockMan1.h"
#include "Cpu.h"


extern const lpit_user_config_t  lpitCom1_InitConfig;
extern const lpit_user_channel_config_t lpitCom1_ChnConfig0;


#endif 


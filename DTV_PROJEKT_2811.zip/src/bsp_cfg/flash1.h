#ifndef flash1_H
#define flash1_H


#include "flash_driver.h"

extern const flash_user_config_t flash1_InitConfig0;


#endif



#ifndef BSP_CFG_IOCOM1_H_
#define BSP_CFG_IOCOM1_H_

#include "pins_driver.h"

extern const pin_settings_config_t UNUSED_PIN_CFG;

#endif 


#ifndef pdbCom1_H
#define pdbCom1_H


#include "Cpu.h"

#define INST_PDB1 (0UL)
#define INST_PDB2 (1UL)


extern const pdb_timer_config_t pdbCom_InitConfig0;

#endif


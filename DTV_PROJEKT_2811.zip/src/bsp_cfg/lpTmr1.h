#ifndef lpTmr1_H
#define lpTmr1_H


#include "clockMan1.h"
#include "Cpu.h"
#include "lptmr_driver.h"

#define INST_LPTMR1 0U



extern const lptmr_config_t lpTmr1_config0;

#endif 


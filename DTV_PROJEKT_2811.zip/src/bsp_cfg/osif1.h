#ifndef osif1_H
#define osif1_H
#include "osif.h"
#include "clockMan1.h"
#include "Cpu.h"




#endif



#ifndef SRC_IRQ_PRIORITY_H_
#define SRC_IRQ_PRIORITY_H_

uint8_t irq_priority_get(uint8_t irq_n);

void irq_priority_set_all_predefined();

#endif 


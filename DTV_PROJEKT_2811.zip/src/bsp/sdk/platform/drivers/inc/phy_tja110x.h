
#ifndef PHY_TJA110X_H
#define PHY_TJA110X_H

#include "phy.h"

#ifdef __cplusplus
extern "C"{
#endif

extern phy_driver_t PHY_driver_tja110x;

#ifdef __cplusplus
}
#endif

#endif 




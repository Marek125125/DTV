
#ifndef PHY_GENERIC_H
#define PHY_GENERIC_H

#include "phy.h"

#ifdef __cplusplus
extern "C"{
#endif

extern phy_driver_t PHY_driver_generic;

#ifdef __cplusplus
}
#endif

#endif 




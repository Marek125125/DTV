
#include "graph_support.h"
#include "module_code.h"
#include "graph_code.h"


uint8_t membitarray[MEMBITARRAY_SIZE]; 
uint16_t mem16array[MEM16ARRAY_SIZE];  
uint32_t mem32array[MEM32ARRAY_SIZE];  

uint16_t ext_graph_cycle_time = 10;

void graphcode_init( void)
{
}

void graphcode( void)
{ 


}



/*----------------------------------------------------------------------------*/
/**
* \file         io_variables.c
* \brief        Source file which contains Applics Studio generated code.
* \details
* \date         20241017
* \author       Applics Studio
*
*/
/*----------------------------------------------------------------------------*/
#include "io_variables.h"


// Variables for graph code VARIABLE_IN and VARIABLE_OUT blocks

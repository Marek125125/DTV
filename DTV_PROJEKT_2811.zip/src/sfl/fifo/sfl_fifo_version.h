#ifndef SFL_FIFO_VERSION_H
#define SFL_FIFO_VERSION_H

#define SFL_FIFO_VERSION     2              

#endif


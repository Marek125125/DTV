#ifndef SFL_BL_PROTOCOL_VERSION_H
#define SFL_BL_PROTOCOL_VERSION_H
#define SFL_BL_PROTOCOL_VERSION     1                       

#endif


#ifndef SFL_MATH_VERSION_H
#define SFL_MATH_VERSION_H


#define SFL_MATH_VERSION     3       
#endif



#include "user_api_system.h"
#include "device_registers.h"


void user_system_soft_reset()
{
    SystemSoftwareReset();
}


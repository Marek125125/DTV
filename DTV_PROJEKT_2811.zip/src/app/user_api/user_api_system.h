#ifndef SRC_APP_USER_API_USER_API_SYSTEM_H_
#define SRC_APP_USER_API_USER_API_SYSTEM_H_

#include <stdint.h>


void user_system_soft_reset();

#endif 



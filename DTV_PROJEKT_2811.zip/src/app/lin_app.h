
#ifndef SRC_APP_LIN_APP_H_
#define SRC_APP_LIN_APP_H_

void lin_init_all();
void lin_cyclic();

#endif 


#ifndef __VERSION_H_
#define __VERSION_H_


#define BASE_SW_VERSION_MAJOR       4
#define BASE_SW_VERSION_MINOR       14
#define BASE_SW_VERSION_BUILD       0
#define GIT_COMMIT_SHA adf170b5

#endif

